﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    public  class DB
    {
        SQLiteConnection connection = new SQLiteConnection("Data Source=db.sqlite3;Version=3;");

        SQLiteConnection GetConnection()
        {
            return connection;
        }

        public void Display(string query, DataGridView dgv)
        {
            string sql = query;
            SQLiteConnection connection = GetConnection();
            SQLiteCommand command = new SQLiteCommand(sql, connection);
            SQLiteDataAdapter adapter = new SQLiteDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dgv.DataSource = dt;
            connection.Close();
        }
    }
}
