﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form2_avtorization : Form
    {
        public Users[] user = new Users[]
        {
            new Users("admin", "123")
        };
        public Form2_avtorization()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < user.Length; i++)
            {
                if (textBox1.Text == user[i].Login && textBox2.Text == user[i].Password)
                {
                Form_capcha f = new Form_capcha();
                f.Show();
                }
                else
                {
                    MessageBox.Show("Повторите попытку");
                }
            }
           
        }

        private void Form2_avtorization_Load(object sender, EventArgs e)
        {

        }
    }
}
