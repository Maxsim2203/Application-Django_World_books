﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form_base : Form
    {
        public Form_base()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form_base_Load(object sender, EventArgs e)
        {
            DB dataBase = new DB();
            dataBase.Display("SELECT id,\r\n       title,\r\n       summary,\r\n       isbn,\r\n       genre_id,\r\n       language_id\r\n  FROM catalog_book;\r\n", dataGridView1);
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
